rm -rf CMakeFiles
rm Makefile
rm CMakeCache.txt
rm cmake_install.cmake
